# Maruchi
Maruchi/マルチ Is a discord multi tool including Ritchi!
