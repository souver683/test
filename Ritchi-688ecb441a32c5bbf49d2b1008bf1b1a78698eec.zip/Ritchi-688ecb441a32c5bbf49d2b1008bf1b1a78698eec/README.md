# Ritchi
An Ine software. Ritchi the easy way for rich presence.

# Discord RPC Tool.
Ritchi is a discord rich presence tool made in JavaScript.
This is a very simple software and its very easy to use.
---

### Installation
On Windows devices just open Ritchi.bat and if its your first time launching open Install.bat too.
On other devices like linux and mac open a console and type `npm i` only execute that command on first use to install the packages and then type `node .` to start the software if node/npm is not installed on your device goto [this link](https://nodejs.org/en/) on some devices you might have to install them both apart through your operating systems package command. Like on arch `pacman -S nodejs npm`.

#### Made By ! EC JΞCTA 伊根#0777
